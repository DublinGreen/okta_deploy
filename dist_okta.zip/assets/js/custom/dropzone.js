(function ($) {
    "use strict";

    // $("#dropzone").dropzone({url: "/file/post"});

})(jQuery);